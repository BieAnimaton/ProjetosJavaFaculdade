package aula6.aula5melhorado;

public abstract class Poligono {
    
    public abstract double calcularPerimetro();    
    public abstract double calcularArea();
}
